# Changelog

## 0.19.8

- **Spread stopped testing every burnable in the world against every fire.**
  A tester's own log finally showed the shape of the problem: hosting on
  0.19.3 with a maxed fire, they had **2176 spread candidates against 50
  burning objects and 46 ground cells**, and `SpreadPass` compared every
  candidate to every burner on each 0.75s cycle. That is roughly a quarter of
  a million distance checks a cycle, each carrying a type dispatch and a ZDO
  lookup — and their measured frametime spikes were 101.9-146.3ms, which is
  where that arithmetic lands.

  Candidates are static — trees and walls do not move — so they are now
  bucketed into a 16m spatial grid whenever the candidate list is rebuilt, and
  a burner only examines the cells its own reach touches. Cost follows the
  size of the fire instead of how much wood is lying around the map.
  Two smaller wins came with it: the cheap distance check now runs BEFORE the
  type dispatch and ZDO lookup rather than after, and bucket lists are pooled
  so re-bucketing does not allocate. Behaviour is unchanged — the same
  candidates ignite, they are just found without walking the whole world.

  Note for anyone reading the old advice: the earlier guess that affected
  testers were simply on the pre-0.18.6 build was WRONG. The tester was on
  0.19.3 and already had every prior performance fix; this loop was the part
  none of them touched.

## 0.19.7

- **`fireset lowspec` typed on a client never reached the server.** 0.19.6
  added `lowspec` to the command's switch but not to the map that forwards a
  setting to the server, so the command set the CLIENT's own config, reported
  success, and left the simulation untouched — the client console showed the
  reduced caps while the server's `firestatus` still read `lowspec False`.
  Caught the first time it was tested live. Every other key was already
  forwarded correctly; an audit of all 47 switch cases against the 47 map
  entries now shows them matching exactly, and the map carries a comment
  saying that adding a case without a map entry produces exactly this silent
  disagreement.

  Verified live afterwards, server-side, against a burning front — three
  consecutive status lines, with `fireset (remote from ...)` in the server log
  proving the command crossed the wire:

  ```
  burning 17/50, ground 42/50, vfxcap 30, dmgcap 50, interval 0.75s, lowspec False
  burning 16/20, ground 18/25, vfxcap 10, dmgcap 20, interval 2s,    lowspec True
  burning 17/50, ground 50/50, vfxcap 30, dmgcap 50, interval 0.75s, lowspec False
  ```

  Every cap dropped and every one came back. Ground cells fell 42 → 18 while
  the preset was on, so the simulation actually shed load rather than merely
  reporting smaller numbers, and the third line is the design's real claim
  observed: turning it off restored the configured values exactly, because
  the preset resolves at read time and never wrote to the config at all.

## 0.19.6

- **`LowSpecPreset` — one switch for a machine that struggles.** Instead of
  learning eight settings, set `LowSpecPreset = true` (or `fireset lowspec
  true`, live, no restart). It caps burning pieces at 20, ground cells at 25,
  ground-fire visuals at 10 and damage zones at 20, drops scorch decals, and
  slows the spread cycle to at least 2s. Fire still spreads and still burns
  things down — there is simply less of it at once.

  Two properties worth stating, because both are easy to get wrong:
  - **It never writes to your config.** The preset resolves at read time, so
    your own values are untouched and switching it back off restores them
    exactly. Implemented by assigning values instead, BepInEx would have
    persisted the preset's numbers over the player's and there would be no
    way back.
  - **It only ever makes things cheaper.** Every cap takes the *lower* of
    yours and the preset's, so anyone already tuned below these keeps their
    own number; the spread interval takes the *higher*, since a longer
    interval is the cheap direction. The preset is a ceiling on cost, never
    an instruction to raise anything.

  `firestatus` reports the values actually in force rather than the
  configured ones, plus a `lowspec` flag, so the line can never disagree with
  what the simulation is enforcing.

## 0.19.5

- **Cut the size of the periodic frametime spike, not just how often it
  happens.** 0.18.6 stopped rebuilding the spread-candidate picture every
  0.75s and cached it for 5s — which made the hitch rarer without making it
  any smaller. Three costs went into each rebuild, and two of them scaled
  with how much stuff was lying around the world rather than with the fire:
  - The **ZDO sector sweep now follows the live fire front** instead of the
    leash. The leash is a lifetime maximum, so a fire five cells across swept
    the same 150m radius as one that had burned for an hour — 7x7 = 49 zones
    every rebuild regardless of size. The radius is now the furthest burner
    plus one full spread reach, still capped at the old figure, so it can
    never sweep more than before and a young fire sweeps one or nine zones.
  - The **`FindObjectsOfType` tree and log scans are now a fallback**, not
    the default. They walk every loaded GameObject in the scene, so their
    cost rides the world's object count — worst exactly where a tester has a
    forest and a field of dropped wood. The ZDO sweep already resolves trees
    and logs authoritatively, so the scans now run only on a peer that could
    not read the ZDO layer at all.
- **Scorch marks and fire VFX stopped allocating per spawn.** Every scorch
  mark called `CreatePrimitive`, which builds a fresh mesh *and* a collider
  only to destroy the collider on the next line, plus a new `Material`; every
  particle effect instantiated its own `Material` too, always with the same
  shader and texture. One shared quad mesh and one shared material each now.
  Marks spawn per burned ground cell, so on a spreading front that churn was
  continuous — and allocation churn on the render thread is the same shape of
  problem 0.18.7 chased out of the logging path.

  Verified in-game on the dedicated server the same day: a relayed
  `startfire 10` lit three trees, and across the burn `zdoCandidates` read 4
  and then 7 — the sweep tracking the front outward exactly as intended —
  while ground fire seeded and spread (0 → 10 cells, then decaying as cells
  exhausted). The failure mode this had to rule out was a sweep too tight to
  find fuel, which would have shown as `zdoCandidates=0` and a fire that sat
  still; neither happened. The SIZE of the saving is still unmeasured — that
  needs a frametime capture, not a log.

## 0.19.4

- **The Dousing Bomb was never missing — the warning was wrong.** Every start,
  client and server alike, logged `donor prefab 'BombOoze' not found in ObjectDB —
  Dousing Bomb unavailable`, then created the bomb successfully four log lines
  later. Registration is hooked to both `ObjectDB.Awake` and `CopyOtherDB` precisely
  because the first Awake fires on the bootstrap ObjectDB, before the game's items
  exist; the retry was always working. Only the logging was wrong, and wrong in the
  worst direction — it told every user a feature was broken when it was not, and it
  spent the one-shot `_failureLogged` flag on a non-event, so a *genuine* absence
  could never have been reported afterwards. The warning now fires only when a fully
  loaded ObjectDB is missing the donor, which is the real fault it was meant to
  describe. No behaviour change: the bomb crafted before this and crafts now.

## 0.19.3

- **`startfire` actually finds targets on a dedicated server.** Caught live
  during relay verification: `startfire 10` in a meadow full of burnables
  answered "attempted 0 targets" — its target scan still walked instance
  lists, which are empty on a headless server (the same root cause the
  0.17.4 spread fix addressed; this command's own scan was never converted).
  It now also sweeps the ZDO layer — the census a headless server actually
  keeps — creating instances only for real ignitions, with anything the
  instance pass already lit skipped so the count never doubles.

## 0.19.2

- **A burned spot can no longer queue two regrown trees.** Seen live: the same
  Beech1 position pending regrowth twice — one entry deep into its retry
  attempts, one fresh — which would have spawned two overlapping trees. Both
  paths that queue regrowth (a tree burning down, and restoring the fire
  sidecar after a restart) now dedupe by position; the existing entry wins
  because its attempt count is real history.

## 0.19.1

- **Fixed relayed commands dying at "Admin only." on clients.** The local
  admin check ran BEFORE the relay, and a client's admin flag only syncs
  after running `devcommands` — so genuine admins got blocked while the
  server's real authorization never got a say (caught live: three commands,
  three rejections, zero relays). Relayable commands now relay first; the
  server judges the sending peer against its own adminlist — the check that
  actually matters — and the local gate only guards direct host/server
  console execution. (Workaround on 0.19.0 clients: run `devcommands` once.)

## 0.19.0

- **Every server command now works from anywhere.** `startfire`,
  `clearfires`, `firegroundignite`, `firetreeregrow`, and
  `firetreeregrowlist` used to refuse with "only works run from the server"
  when typed on a client. They now relay: the command runs on the server —
  authorized against the server's own adminlist for the SENDING peer,
  vanilla's exact kick/ban check, never the typist's local claim — and every
  line of output streams back to your console as `[server] ...`. Radius
  commands act around the requesting player (the server-tracked position, not
  a client-supplied one). Only a fixed whitelist of FireFront's own commands
  can relay; crosshair commands (`ignite`, `stopfire`) keep their dedicated
  forwards since target picking is inherently local.

## 0.18.8

- **`firestatus` answers from the server.** A client's local status always
  read burning 0 / ground 0 — the counts live on the server. It now requests
  the authoritative line and prints it as `[server] FireFront: ...`.

## 0.18.7

- **Killed the GC frame spikes — debug logging is now free when off.** A tester
  clip (steady ~10ms baseline, CPU and GPU both far from saturated, isolated
  spikes to ~80ms every few seconds) showed the signature of Mono GC pauses.
  The feeder: every debug trace built its log string BEFORE checking whether
  debug logging was on — hundreds of dead strings a second during a big fire —
  and debug logging also defaulted ON, adding BepInEx console/file I/O on top.
  Debug calls now use an interpolated-string handler (the compiler skips all
  formatting when disabled, verified in the compiled output), and the config
  key was renamed VerboseLogging → DebugLogging (default off) so existing
  configs stuck on the old always-on default go quiet on upgrade. `firedebug`
  still toggles it live when you actually want the firehose.

## 0.18.6

- **Fixed the periodic frametime spike during big fires.** Two causes, both
  cadence-shaped: the server rebuilt its whole spread-candidate picture every
  0.75s cycle (three scene scans plus a ZDO sector sweep whose radius follows
  the ground leash — at leash 150m that walked 49 zones per cycle), and the
  client spawned a full second's batch of ground-fire particle systems in one
  frame on every sync flush. Candidates are static trees and walls, so the
  scan is now cached and rebuilt every 5s (immediately on a new fire); remote
  VFX spawns drain a few per frame from a queue. No behavior change — same
  fire, smoother frames, biggest win on machines hosting server and client
  together.

## 0.18.5

- **Front pace now tied to burn time.** A burning object must burn
  `SpreadMaturityFraction` of its burn duration (default 0.25 — about a minute
  at the default 240s burn) before it can ignite neighbors or seed the ground
  under itself. Before, a just-caught tree could torch its entire reach on the
  very next spread cycle while itself burning for four minutes, so the front
  raced ahead at a pace disconnected from the fuel. A burning-but-immature
  tree still glows and hurts — it just isn't throwing fire yet. Ground fire's
  own cell-to-cell crawl is unchanged. `fireset firematurity`, 0 restores the
  old instant contagion. Burn age persists across restarts (restored fires
  keep their maturity).

## 0.18.4

- **Dousing now holds — firefighting is winnable.** Anything deliberately
  extinguished (dousing bomb, extinguish key, stopfire) is soaked for
  `DouseImmunitySeconds` (default 90s, `fireset douseimmunity`) and can't
  re-ignite. Before this, the surrounding fire re-lit every doused cell and
  object within a cycle or two, so a bomb's cleared hole refilled itself in
  seconds and a ramped fire was hopeless to fight ("the ramp is too aggressive
  to fight" — the ramp was fine; the dousing just didn't stick). Now a line of
  bombs cuts a genuine firebreak ahead of the front. 0 disables.

## 0.18.3

- **`fireset` now applies on the server no matter where you type it.** Console
  commands run where they're typed, and every FireFront setting that matters is
  read by the server's simulation — so a client's fireset used to change its own
  irrelevant config copy and silently do nothing ("rampstart didn't work",
  "burnbuildings didn't work"). A client's fireset now also forwards to the
  server over a new RPC and lands on the server's real config, with the same
  value parsing and range clamping. The server logs every remote set with the
  sender's peer id.

## 0.18.2

- **New config `BurnPlayerBuildings` (default true) + `fireset burnbuildings`.**
  Set false for an anti-grief server: fire never ignites anything carrying a
  placement creator stamp — walls, floors, furniture — by any path (spread, fire
  arrows, console), while world-generated structures still burn. The wildfire
  still crawls past a protected base and still hurts anyone standing in it. This
  is the hard guarantee on top of the terrain firebreak, which already stops
  spread at leveled/pathed base ground but not deliberate arson.

## 0.18.1

- **Fixed: fire went invisible for a client that reconnected without relaunching.**
  Valheim creates a fresh routing instance per connection; FireFront registered its
  network handlers once per process, so a client kicked by a server restart that
  auto-rejoined got none of the fire broadcasts — the fire burned, invisibly, until
  the game was fully relaunched. Handlers now re-register whenever the routing
  instance changes. Receipt-side `[SYNC-DIAG]` debug traces are kept so this class
  of silent drop is diagnosable from a single log in future.

## 0.18.0

- **Fires survive server restarts.** Burning objects and ground fire come back with
  their remaining burn time, spent fuel stays spent, the fire keeps its origin,
  ramp age, and arsonist, and trees waiting to regrow still regrow. Stored in a
  small sidecar file next to the world save, written every 60s and on shutdown —
  a hard kill loses at most the last minute of fire drift. Toggle with `fireset
  persistfires`.

## 0.17.6

- Fixed a `FieldAccessException` spamming the main menu from 0.17.5's item
  registration (a private-in-the-real-assembly ObjectDB field). Registration
  failures now degrade to "item missing" with one warning, never menu errors.

## 0.17.5

- **New item: the Dousing Bomb.** A throwable that extinguishes everything within
  ~6m of impact — ground fire and burning structures/trees alike. Hand-craftable:
  3 Resin + 2 Leather scraps makes 3. Tune the blast with `fireset dousingradius`.
- The extinguish key's radius now also clears burning objects around you, not just
  ground fire.

## 0.17.4

- **Forest spread now actually works on dedicated servers.** Object-to-object and
  ground-to-object spread had never worked there — the headless server tracks the
  world as ZDOs and never instantiates the GameObjects the old candidate scan
  looked for, so the server literally could not see trees. Spread candidates now
  come from the ZDO layer, and an instance is created only for objects that
  actually catch fire.

## 0.17.3

- **Fires remember who lit them.** The spreading front carries its igniter's player
  id, captured once per fire event from the actual attacker (not the network sender),
  and reset when the fires die. Natural and creature fire belongs to nobody. This
  feeds Ragnarok's Wrath's arson attribution.
- The ignite request RPC was renamed so a mixed-version server/client pair quietly
  no-ops instead of desyncing — update both sides together.

## 0.17.2

- **Wind bias now scales with real wind strength.** A gale drives a long narrow
  tongue of fire; dead calm burns evenly in all directions. `WindInfluence` (0–1,
  default 1) dials how much weather shapes the front.
- Public read API (`FireManager.CollectActiveFirePositions`) for companion mods —
  Ragnarok's Wrath reads it to scar burning zones.

## 0.17.0 – 0.17.1

- Procedural fire visuals now default **on** — earlier builds simulated fire fully
  but rendered nothing until a console toggle. Upgrading an existing install? BepInEx
  keeps your old `UseProceduralVfx = false`; flip it to true or delete the line.
- Floating ground fire fixed for real: terrain height now raycasts Valheim's own
  terrain layer instead of trusting a call that echoed its input back.

## Earlier (0.1 – 0.16)

The road here, condensed: ignition from vanilla fire damage; spread with caps, a
queue, and ramp-up; ground fire as an invisible cell grid with its own visuals,
damage, and a 40m leash; rain suppression; firebreaks on dirt and cultivated ground;
water blocking; fuel exhaustion and burn scars; tree felling with real drops and
timed regrowth; the G-key extinguisher. The full engineering log — every bug and
what it taught — lives in the repo at `docs/DEVLOG.md`.
